from flask import Flask, render_template, request, render_template_string, abort
import base64
from Crypto.Cipher import AES
import binascii
import inspect

app = Flask(__name__, template_folder='./templates')
key = b'0123456789abcdef'


# 解密函数
def decrypt(text):
    """
    # 此函数将在如下代码执行时进行调用
    path = request.path.strip('/')
    解密路径
    decrypted_path = decrypt(path.encode())
    """
    cipher = AES.new(key, AES.MODE_ECB)
    try:
        decrypted_text = cipher.decrypt(binascii.unhexlify(text))
        return decrypted_text.rstrip(b' ').decode()
    except Exception as e:
        source_code = inspect.getsource(decrypt)
        # return render_template_string(f"Error: {str(e)}Decrypt function source code:%s " %  source_code)
        error_message = f"Error: {str(e)}<br><br>Decrypt function source code:<br><pre>{source_code}</pre>"
        return error_message


# 模拟根目录下的 flag 文件内容
flag_content = "This is the flag content!"


# 路由处理函数
@app.route('/')
def index():
    # 加载欢迎页面
    # return render_template("html/index.html")
    # return render_template("index.html")
    response = app.make_response(render_template("index.html"))
    response.headers['X-AES-Key-Base64'] = base64.b64encode(key).decode()
    response.headers['X-AES-Key-bit'] = 128
    return response


# 错误处理页面
@app.errorhandler(404)
def page_not_found(e):
    # 获取请求的 URL 路径
    path = request.path.strip('/')
    # 解密路径
    decrypted_path = decrypt(path.encode())
    template = '''
            <div class="center-content error">
                <p> 404 Page </>
                <p>URL Path  %s  is Not Found</p>
            </div>
        ''' % decrypted_path
    return render_template_string(template), 404


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=9000, debug=True)