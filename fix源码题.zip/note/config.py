

class Config(object):
    SECRET_KEY = 'you-will-never-guess-hahahahahaha2333'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:root@mysql:3306/ctf?charset=utf8mb4'
