from flask_wtf import FlaskForm
from wtforms import *
from wtforms.validators import DataRequired


class CreateNoteForm(FlaskForm):
    username = StringField('笔记用户名', validators=[DataRequired()])
    title = StringField('笔记标题', validators=[DataRequired()])
    body = TextAreaField('笔记内容', validators=[DataRequired()])
    private = BooleanField('私人笔记', default='0')
    submit = SubmitField('Go')


