<?php echo "flag{th1s_is_f4ke_flag}<br><br><br><br><br>\n"?>
But,there is something in coooooomand.php~!!