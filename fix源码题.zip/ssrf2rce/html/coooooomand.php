<?php
function executeCommand($command) {
    if (preg_match('/cat| |\\\\|\${IFS}|%09|\$[*@x]|tac|bat|more|less|nl|od|sed|awk|perl|python|ruby|xxd|hexdump|string/', $command)) {
        return "Hacker!!!";
    }

    $output = shell_exec($command);
    if ($output === null) {
        return "uhhhh";
    }

    return $output;
}

$command = isset($_GET['command']) ? $_GET['command'] : '';

if (!empty($command)) {
    $result = executeCommand($command);
    echo nl2br(htmlspecialchars($result, ENT_QUOTES, 'UTF-8'));
} else {
    echo highlight_file(__FILE__, true);
}
?>
