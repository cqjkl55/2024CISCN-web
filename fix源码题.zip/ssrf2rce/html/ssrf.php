<?php
function fetchUrl($url) {
    if (!preg_match('/^http:\/\/ciscn\..*?@127\.0\.0\.1\/flag\.php\?look$/i', $url)) {
        return "Almost Done~";
    }

    if (strpos($url, 'file://') !== false) {
        return "Accessing files via file protocol is not allowed";
    }

    
    $flagContent = @file_get_contents('/var/www/guess/fllllllaaaaaaag.php');

    if ($flagContent === false) {
        return "Error accessing flag file";
    }

    return $flagContent;
}

$userInput = isset($_GET['url']) ? $_GET['url'] : '';

if (empty($userInput)) {
    echo highlight_file(__FILE__, true);
} else {
    $result = fetchUrl($userInput);
    echo $result;
}
?>
