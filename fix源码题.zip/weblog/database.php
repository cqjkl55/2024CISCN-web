<?php
    error_reporting(0);
    define('MYSQL_SERVER', 'localhost') ;
    define('MYSQL_USER', 'ctf') ;
    define('MYSQL_PASSWORD', 'ctf') ;
    define('MYSQL_DB', 'blog') ;

    //connect to mysql
    function db_connect(){
        $link = mysqli_connect(MYSQL_SERVER, MYSQL_USER, MYSQL_PASSWORD, MYSQL_DB) or die ("Error: ".mysqli_error($link));
        if(!mysqli_set_charset($link, "utf8")) {
            printf("Error: ".mysqli_error($link));
        }

        return $link;
    }

    // test to connect
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if(isset($_POST['jsonData'])){
            $postData = json_decode($_POST['jsonData'], true);

            if($postData !== null){
                $link = mysqli_query(mysqli_connect($postData['host'],$postData['username'],$postData['password'],$postData['database'],$postData['port']), "set names utf8");
                        if ($link){
                            echo "<script>alert('success')</script>";
                        }else{
                            echo "<script>alert('failed')</script>";
                        }
            } else {
                echo "Failed to decode JSON data";
            }
        } else {
            echo "No jsonData parameter received";
        }
    } else {
        echo "No POST request received";
    }
?>
