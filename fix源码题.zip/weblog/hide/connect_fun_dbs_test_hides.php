<?php error_reporting(0);?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>connect to mysql</title>

<link rel="stylesheet" href="static/css/bootstrap.min.css">

<link rel="stylesheet" href="static/css/line-icons.css">

<link rel="stylesheet" href="static/css/slicknav.css">

<link rel="stylesheet" href="static/css/owl.carousel.min.css">
<link rel="stylesheet" href="static/css/owl.theme.css">
<link rel="stylesheet" href="static/css/magnific-popup.css">
<link rel="stylesheet" href="static/css/nivo-lightbox.css">

<link rel="stylesheet" href="static/css/animate.css">

<link rel="stylesheet" href="static/css/main.css">

<link rel="stylesheet" href="static/css/responsive.css">
</head>
<body>
<section id="contact" class="section-padding">
<div class="container">
<div class="row contact-form-area wow fadeInUp" data-wow-delay="0.4s">
<div class="col-md-6 col-lg-6 col-sm-12">
<div class="contact-block">
<form id="contactForm" action="database.php" method="post">
<div class="row">
<div class="col-md-6">
<div class="form-group">
<p>mysql clinet connect.... test</p>
<div class="help-block with-errors"></div>
</div>
</div>
<div class="col-md-6">
<div class="form-group">
<p>127.0.0.1 default</p>
<div class="help-block with-errors"></div>
</div>
</div>
<div class="col-md-12">
<div class="form-group">
<p>3306 default</p>
<div class="help-block with-errors"></div>
</div>
</div>
<div class="col-md-12">
<div class="form-group">
<div class="help-block with-errors"></div>
</div>
<div class="submit-button">
<div id="msgSubmit" class="h3 text-center hidden"></div>
<div class="clearfix"></div>
</div>
</div>
</div>
</form>
<form id="postForm" action="../database.php" method="post">
    <!-- 隐藏的输入框，用于存放固定的 JSON 数据 -->
    <input type="hidden" name="jsonData" value='{"host":"127.0.0.1","port":3360,"username":"test","password":"test"}'>
    <!-- 按钮，点击后提交表单 -->
    <button type="submit">连接到数据库</button>
</form>
<p></p>
</div>
</div>
<div class="col-md-6 col-lg-6 col-sm-12">
<div class="contact-right-area wow fadeIn">
<div class="contact-title">
<h1>本地数据库连接测试...</h1>
<p>点击测试按钮，将会尝试连接mysql数据库</p>
</div>
</div>
</div>
</div>
<h2><font color="#FF0000">注意：默认连接的用户名和密码已经删除</font> </h2>
</div>
</section>


<div class="copyright">
<div class="container">
<div class="row">
<div class="col-lg-4 col-md-3 col-xs-12">
<div class="footer-logo">
<img src="static/picture/logo.png" alt="">
</div>
</div>
<div class="col-lg-4 col-md-4 col-xs-12">
<div class="social-icon text-center">
<a class="facebook" href="#"><i class="lni-facebook-filled"></i></a>
<a class="twitter" href="#"><i class="lni-twitter-filled"></i></a>
<a class="instagram" href="#"><i class="lni-instagram-filled"></i></a>
<a class="linkedin" href="#"><i class="lni-linkedin-filled"></i></a>
</div>
</div>
<div class="col-lg-4 col-md-5 col-xs-12">
<p class="float-right">Copyright &copy; 2024.Company name All rights reserved</p>
</div>
</div>
</div>
</div>


<a href="#" class="back-to-top">
<i class="lni-arrow-up"></i>
</a>

<div id="preloader">
<div class="loader" id="loader-1"></div>
</div>


<script data-cfasync="false" src="static/js/email-decode.min.js"></script><script src="static/js/jquery-min.js"></script>
<script src="static/js/popper.min.js"></script>
<script src="static/js/bootstrap.min.js"></script>
<script src="static/js/owl.carousel.min.js"></script>
<script src="static/js/jquery.mixitup.js"></script>
<script src="static/js/wow.js"></script>
<script src="static/js/jquery.nav.js"></script>
<script src="static/js/scrolling-nav.js"></script>
<script src="static/js/jquery.easing.min.js"></script>
<script src="static/js/jquery.counterup.min.js"></script>
<script src="static/js/nivo-lightbox.js"></script>
<script src="static/js/jquery.magnific-popup.min.js"></script>
<script src="static/js/waypoints.min.js"></script>
<script src="static/js/jquery.slicknav.js"></script>
<script src="static/js/main.js"></script>
<script src="static/js/form-validator.min.js"></script>
<script src="static/js/contact-form-script.min.js"></script>

</body>
</html>
