<?php error_reporting(0);?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Stack - Bootstrap 4 Business</title>

<link rel="stylesheet" href="static/css/bootstrap.min.css">

<link rel="stylesheet" href="static/css/line-icons.css">

<link rel="stylesheet" href="static/css/slicknav.css">

<link rel="stylesheet" href="static/css/owl.carousel.min.css">
<link rel="stylesheet" href="static/css/owl.theme.css">
<link rel="stylesheet" href="static/css/magnific-popup.css">
<link rel="stylesheet" href="static/css/nivo-lightbox.css">

<link rel="stylesheet" href="static/css/animate.css">

<link rel="stylesheet" href="static/css/main.css">

<link rel="stylesheet" href="static/css/responsive.css">
</head>
<body>


<div class="col-md-6 col-lg-4 col-xs-12">
<div class="services-item wow fadeInRight" data-wow-delay="0.3s">
<div class="icon">
<i class="lni-pencil"></i>
</div>
<div class="services-content">
<h3><?=htmlspecialchars($article['title']);?></h3>
<p><?=htmlspecialchars($article['content']);?></p>
<em><?=htmlspecialchars($article['date'])?></em>
</div>
</div>
</div>


</div>
</div>
</section>

<div class="col-lg-4 col-md-5 col-xs-12">
<p class="float-right">Copyright &copy; 2024.Company name All rights reserved.</p>
</div>


<a href="#" class="back-to-top">
<i class="lni-arrow-up"></i>
</a>

<div id="preloader">
<div class="loader" id="loader-1"></div>
</div>


<script data-cfasync="false" src="static/js/email-decode.min.js"></script><script src="static/js/jquery-min.js"></script>
<script src="static/js/popper.min.js"></script>
<script src="static/js/bootstrap.min.js"></script>
<script src="static/js/owl.carousel.min.js"></script>
<script src="static/js/jquery.mixitup.js"></script>
<script src="static/js/wow.js"></script>
<script src="static/js/jquery.nav.js"></script>
<script src="static/js/scrolling-nav.js"></script>
<script src="static/js/jquery.easing.min.js"></script>
<script src="static/js/jquery.counterup.min.js"></script>
<script src="static/js/nivo-lightbox.js"></script>
<script src="static/js/jquery.magnific-popup.min.js"></script>
<script src="static/js/waypoints.min.js"></script>
<script src="static/js/jquery.slicknav.js"></script>
<script src="static/js/main.js"></script>
<script src="static/js/form-validator.min.js"></script>
<script src="static/js/contact-form-script.min.js"></script>
</body>
</html>
