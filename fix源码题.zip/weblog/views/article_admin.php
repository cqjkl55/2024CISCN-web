<?php error_reporting(0);?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>php blog</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="container">
       <h1>php blog</h1>
        <div>
        <form action="index.php?action=<?=htmlspecialchars($_GET['action']);?>&<?php if(isset($_GET['id'])){echo htmlspecialchars($_GET['id']);} ?>" method="post">
            <label>title<br>
                <input type="text" name="title" value="<?=htmlspecialchars($article['title']);?>" class="form-item" autofocus required>
            </label>
            <br>
            <label>date<br>
                <input type="date" name="date" value="<?=htmlspecialchars($article['date']);?>" class="form-item" required>
            </label>
            <br>
            <label>content<br>
                <textarea class="form-item" name="content" required><?=htmlspecialchars($article['content']);?></textarea>
            </label><br>
            <input type="submit" value="Submit" class="btn">
        </form>
        </div>
    <footer>
        <p>Copyright &copy; 2024</p>
    </footer>
    </div>
</body>
</html>
