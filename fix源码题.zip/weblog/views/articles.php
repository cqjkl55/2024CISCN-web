<?php error_reporting(0);?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Stack - Bootstrap 4 Business</title>

<link rel="stylesheet" href="static/css/bootstrap.min.css">

<link rel="stylesheet" href="static/css/line-icons.css">

<link rel="stylesheet" href="static/css/slicknav.css">

<link rel="stylesheet" href="static/css/owl.carousel.min.css">
<link rel="stylesheet" href="static/css/owl.theme.css">
<link rel="stylesheet" href="static/css/magnific-popup.css">
<link rel="stylesheet" href="static/css/nivo-lightbox.css">

<link rel="stylesheet" href="static/css/animate.css">

<link rel="stylesheet" href="static/css/main.css">

<link rel="stylesheet" href="static/css/responsive.css">
</head>
<body>

<header id="header-wrap">

<nav class="navbar navbar-expand-md bg-inverse fixed-top scrolling-navbar">
<div class="container">

<a href="index1.html" class="navbar-brand"><img src="static/picture/logo.png" alt=""></a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
<i class="lni-menu"></i>
</button>
<div class="collapse navbar-collapse" id="navbarCollapse">
<ul class="navbar-nav mr-auto w-100 justify-content-end clearfix">
<li class="nav-item active">
<a class="nav-link" href="#hero-area">
Home
</a>
</li>
<li class="nav-item">
<a class="nav-link" href="#feature">
Feature
</a>
</li>
<li class="nav-item">
<a class="nav-link" href="#services">
Services
</a>
</li>
<li class="nav-item">
<a class="nav-link" href="#team">
Team
</a>
</li>
<li class="nav-item">
<a class="nav-link" href="#pricing">
Pricing
</a>
</li>
<li class="nav-item">
<a class="nav-link" href="#portfolios">
Works
</a>
</li>
<li class="nav-item">
<a class="nav-link" href="#testimonial">
Testimonial
</a>
</li>
<li class="nav-item">
<a class="nav-link" href="#blog">
Blog
</a>
</li>
<li class="nav-item">
<a class="nav-link" href="#contact">
Contact
</a>
</li>
</ul>
</div>
</div>
</nav>


<div id="hero-area" class="hero-area-bg">
<div class="container">
<div class="row">
<div class="col-md-12 col-sm-12">
<div class="contents text-center">
<h2 class="head-title wow fadeInUp">We Discover, Design & Build Digital <br> Presence of Businesses</h2>
<div class="header-button wow fadeInUp" data-wow-delay="0.3s">
<a href="javascript:;" rel="nofollow" target="_blank" class="btn btn-common">Download Now</a>
</div>
</div>
<div class="img-thumb text-center wow fadeInUp" data-wow-delay="0.6s">
<img class="img-fluid" src="static/picture/hero-1.png" alt="">
</div>
</div>
</div>
</div>
</div>

</header>


<div id="feature">
<div class="container-fluid">
<div class="row">
<div class="col-lg-6 col-md-12 col-sm-12">
<div class="text-wrapper">
<div>
<h2 class="title-hl wow fadeInLeft" data-wow-delay="0.3s">We are helping to grow <br> your business.</h2>
<p class="mb-4">A digital studio specialising in User Experience & eCommerce, we combine innovation with digital craftsmanship to help brands fulfill their potential.</p>
<a href="#" class="btn btn-common">More About Us</a>
</div>
</div>
</div>
<div class="col-lg-6 col-md-12 col-sm-12 padding-none feature-bg">
<div class="feature-thumb">
<div class="feature-item wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
<div class="icon">
<i class="lni-microphone"></i>
</div>
<div class="feature-content">
<h3>What we do</h3>
<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia con- sequuntur magni dolores </p>
</div>
</div>
<div class="feature-item wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="500ms">
<div class="icon">
<i class="lni-users"></i>
</div>
<div class="feature-content">
<h3>Meet our team</h3>
<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia con- sequuntur magni dolores </p>
</div>
</div>
<div class="feature-item wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="700ms">
<div class="icon">
<i class="lni-medall-alt"></i>
</div>
<div class="feature-content">
<h3>Our Creation</h3>
<p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia con- sequuntur magni dolores </p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<section id="services" class="section-padding bg-gray">
<div class="container">
<div class="section-header text-center">
<h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Our message</h2>
<p>Below is our message between community contributors in technology <br> began to grow in 2024.</p>
</div>
<div class="row">

<?php foreach($articles as $a): ?>
<div class="col-md-6 col-lg-4 col-xs-12">
<div class="services-item wow fadeInRight" data-wow-delay="0.3s">
<div class="icon">
<i class="lni-pencil"></i>
</div>
<div class="services-content">
<h3><a href="article.php?id=<?=htmlspecialchars($a['id']);?>"><?=htmlspecialchars($a['title']);?></a></h3>
<p><?=articles_intro($a['content'])?></p>
<em><?=htmlspecialchars($a['date']);?></em>
</div>
</div>
</div>
<?php endforeach ?>

</div>
</div>
</section>

<div class="col-lg-4 col-md-5 col-xs-12">
<p class="float-right">Copyright &copy; 2024.Company name All rights reserved.</p>
</div>


<a href="#" class="back-to-top">
<i class="lni-arrow-up"></i>
</a>

<div id="preloader">
<div class="loader" id="loader-1"></div>
</div>


<script data-cfasync="false" src="static/js/email-decode.min.js"></script><script src="static/js/jquery-min.js"></script>
<script src="static/js/popper.min.js"></script>
<script src="static/js/bootstrap.min.js"></script>
<script src="static/js/owl.carousel.min.js"></script>
<script src="static/js/jquery.mixitup.js"></script>
<script src="static/js/wow.js"></script>
<script src="static/js/jquery.nav.js"></script>
<script src="static/js/scrolling-nav.js"></script>
<script src="static/js/jquery.easing.min.js"></script>
<script src="static/js/jquery.counterup.min.js"></script>
<script src="static/js/nivo-lightbox.js"></script>
<script src="static/js/jquery.magnific-popup.min.js"></script>
<script src="static/js/waypoints.min.js"></script>
<script src="static/js/jquery.slicknav.js"></script>
<script src="static/js/main.js"></script>
<script src="static/js/form-validator.min.js"></script>
<script src="static/js/contact-form-script.min.js"></script>
</body>
</html>