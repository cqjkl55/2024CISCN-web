<?php error_reporting(0);?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>php blog</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="container">
        <h1>php blog</h1>
		<hr>
		<a href="index.php?action=add" >create a new article</a>
			<br>
        <div>
			
            <table class="admin-table" >
                <tr>
                    <th>date</th>
                    <th>title</th>
                    <th>edit</th>
                    <th>delete</th>
                </tr>

                <?php foreach($articles as $a): ?>

                    <tr>
                        <td><?=htmlspecialchars($a['date']);?></td>
                        <td><?=htmlspecialchars($a['title']);?></td>
                        <td> <a href="index.php?action=edit&id=<?=htmlspecialchars($a['id']);?>">edit</a> </td>
                        <td> <a href="index.php?action=delete&id=<?=htmlspecialchars($a['id']);?>">delete</a>  </td>
                    </tr>

                <?php endforeach ?>
            </table>



          </div>
		  <hr>
          <footer>
            <p>
            Copyright &copy; 2024
            </p>
          </footer>
    </div>
</body>
</html>
