<?php
define('HOSTS_DIR', __DIR__ . '/../hostsopNsarKlwy/');
?>
