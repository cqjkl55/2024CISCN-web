<?php
    $xml_format = <<<XML
<host>
    <hostname>$hostname</hostname>
    <ip>$ip</ip>
    <port>$port</port>
</host>
XML;
?>
