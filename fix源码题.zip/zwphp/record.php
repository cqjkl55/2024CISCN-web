<?php
require_once 'modules/config.php';

if (isset($_POST['hostname']) && isset($_POST['ip']) && isset($_POST['port'])) {
    $hostname = $_POST['hostname'];
    $ip = $_POST['ip'];
    $port = intval($_POST['port']);

    if (strlen($hostname) > 6 || !filter_var($ip, FILTER_VALIDATE_IP) || $port < 1 || $port > 65535) {
        $result = "输入有误,主机名不大于6个字符，ip格式要正确，端口为正确的端口范围";
        header("Location: record.html?result=" . urlencode($result));
        exit();
    }

    $xml_file = HOSTS_DIR . "{$ip}.xml";
    if (file_exists($xml_file)) {
        $result = "IP已存在";
        header("Location: record.html?result=" . urlencode($result));
        exit();
    }

    include "modules/function.php";

    extract($_REQUEST);

    ${'xml_format'} = $xml_format;

    file_put_contents($xml_file, $xml_format);
    $result = "主机信息已录入";
    header("Location: record.html?result=" . urlencode($result));
    exit();
} else {
    $result = "所有字段均为必填";
    header("Location: record.html?result=" . urlencode($result));
    exit();
}
?>
