<?php
require_once 'modules/config.php';

if (isset($_POST['ip']) && filter_var($_POST['ip'], FILTER_VALIDATE_IP) && isset($_POST['port']) && is_numeric($_POST['port'])) {
    $ip = $_POST['ip'];
    $port = intval($_POST['port']);
    $xml_file = HOSTS_DIR . "{$ip}.xml";

    if (file_exists($xml_file)) {
        $user_info_xml = file_get_contents($xml_file);
        $dom = new DOMDocument();
        $dom->loadXML($user_info_xml, LIBXML_NOENT | LIBXML_DTDLOAD);
        $xml = simplexml_import_dom($dom);
        $stored_port = intval($xml->port);
        $stored_hostname = $xml->hostname;

        if ($stored_port === $port) {
            $result = "搜索的主机存在，端口正确";
   //         $hidden_port = $stored_port;
            header('X-Hidden-Hostname: ' . $stored_hostname);
        } else {
            $result = "搜索的主机存在，但是端口不匹配";
      //      $hidden_port = "";
        }
    } else {
        $result = "主机信息不存在";
      //  $hidden_port = "";
    }
    header("Location: search.html?result=" . urlencode($result));
    exit();
} else {
    die("无效的输入");
}
?>
